package main

//Attack holds information on a attack
type Attackz struct {
	Name        string
	Description string
	Enabled     bool
	Vip         bool
	Premium     bool
	Home        bool
	API         string
}
